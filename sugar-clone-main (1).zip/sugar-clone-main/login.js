let login = () => {
  return `
    <div id="signappend"></div>
    <div id="navlogin">
      <p>
        <span><i class="fa-solid fa-user"></i></span>&nbsp;&nbsp;<div id="changename">Login/Register</div>
      </p>
    </div>`
}
export { login }
